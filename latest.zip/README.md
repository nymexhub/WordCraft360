# 750Writer
Word Counter & Toolkit Platform for Writers: Inspired by the site 750words.com. This is a reverse-engineered version, completely Open Source.


# Author
By Computer Science Engineer: Felipe Alfonso Gonzalez / EMail: (f.alfonso@res-ear.ch)
